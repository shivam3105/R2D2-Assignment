    @extends('layout')
    @section('content')
    <!-- ***** Breadcrumb Area Start ***** -->
    <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">
                    <div class="breadcumb--con">
                        <h2 class="title">International News</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">International News</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background Curve -->
        <div class="breadcrumb-bg-curve">
            <img src="./img/core-img/curve-5.png" alt="">
        </div>
    </div>

    <section class="uza-about-us-area">
        <div class="container">
            <div class="row align-items-center">

                <!-- About Thumbnail -->
                <div class="col-12 col-md-6">
                    <div class="about-us-thumbnail mb-80">
                        <img src="./img/bg-img/in1.jpg" alt="">
                        <!-- Video Area -->
                        
                    </div>
                </div>

                <!-- About Us Content -->
                <div class="col-12 col-md-6">
                    <div class="about-us-content mb-80">
                        <h3>5.8 magnitude earthquake hits Izu Islands in Japan</h3>
                        <p>News is important for a number of reasons within a society. Mainly to inform the public about events that are around them and may affect them. Often news is for entertainment purposes too; to provide a distraction of information about other places people are unable to get to or have little influence over.</p>
                        <a href="https://www.indiatoday.in/world/story/5-8-magnitude-earthquake-hits-izu-islands-in-japan-1494902-2019-04-05" class="btn uza-btn btn-2 mt-4" target="blank">Read More</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- About Background Pattern -->
        <div class="about-bg-pattern">
            <img src="./img/core-img/curve-2.png" alt="">
        </div>
    </section>

    <section class="uza-about-us-area">
        <div class="container">
            <div class="row align-items-center">

                <!-- About Thumbnail -->
                <div class="col-12 col-md-6">
                    <div class="about-us-thumbnail mb-80">
                        <img src="./img/bg-img/in2.jpg" alt="">
                        <!-- Video Area -->
                        
                    </div>
                </div>

                <!-- About Us Content -->
                <div class="col-12 col-md-6">
                    <div class="about-us-content mb-80">
                        <h3>US: Indian involved in call centre scam sentenced to 8 years in jail</h3>
                        <p>Court documents indicate that Nishit Kumar Patel connived with the US-based co-conspirators and the India-based call centres to extort money from American residents by impersonating Internal Revenue Service (IRS) officers between 2014 and 2016.</p>
                        <a href="https://www.indiatoday.in/world/story/us-indian-involved-in-call-centre-scam-sentenced-to-8-years-in-jail-1491814-2019-04-02" class="btn uza-btn btn-2 mt-4" target="blank">Read More</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- About Background Pattern -->
        <div class="about-bg-pattern">
            <img src="./img/core-img/curve-2.png" alt="">
        </div>
    </section>

    <section class="uza-about-us-area">
        <div class="container">
            <div class="row align-items-center">

                <!-- About Thumbnail -->
                <div class="col-12 col-md-6">
                    <div class="about-us-thumbnail mb-80">
                        <img src="./img/bg-img/in3.jpg" alt="">
                        <!-- Video Area -->
                        
                    </div>
                </div>

                <!-- About Us Content -->
                <div class="col-12 col-md-6">
                    <div class="about-us-content mb-80">
                        <h3>Don’t complicate Masood Azhar’s listing by forcefully moving resolution in UNSC: China to USA</h3>
                        <p>China has always been shielding Masood Azhar and Pakistan by always opposing global effort to declare Masood Azhar a global terrorist.</p>
                        <a href="https://www.indiatoday.in/world/story/don-t-complicate-masood-azhar-s-listing-by-forcefuly-moving-resolution-in-unsc-china-to-usa-1488541-2019-03-28" class="btn uza-btn btn-2 mt-4" target="blank">Read More</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- About Background Pattern -->
        <div class="about-bg-pattern">
            <img src="./img/core-img/curve-2.png" alt="">
        </div>
    </section>

    <!-- ***** Blog Area Start ***** -->
    <section class="uza-blog-area">
        <!-- Background Curve -->
        <div class="blog-bg-curve">
            <img src="./img/core-img/curve-4.png" alt="">
        </div>

        <div class="container">
            <div class="row">
                <!-- Section Heading -->
                <div class="col-12">
                    <div class="section-heading text-center">
                        <h2>More News</h2>
                        <!-- <p>Hit the button below or give us a call!</p> -->
                    </div>
                </div>
            </div>

            <div class="row">

                <!-- Single Blog Post -->
                <div class="col-12 col-lg-4">
                    <div class="single-blog-post bg-img mb-80" style="background-image: url(./img/bg-img/in4.jpg);">
                        <!-- Post Content -->
                        <div class="post-content">
                            <span class="post-date"><span>27</span> March, 2019</span>
                            <h4>Mission Shakti: Pakistan urges world to slam India, China calls for peace</h4>
                            <p>Reacting to launch of Mission Shakti, China expressed hope that all countries will uphold peace and tranquillity in the outer space. Pakistan said that countries should use space technologies only for socio-economic development.</p>
                            <a href="https://www.indiatoday.in/world/story/mission-shakti-anti-satellite-missile-pakistan-china-1487866-2019-03-27" class="read-more-btn" target="blank">Read More <i class="arrow_carrot-2right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Single Blog Post -->
                <div class="col-12 col-lg-4">
                    <div class="single-blog-post bg-img mb-80" style="background-image: url(./img/bg-img/in5.jpg);">
                        <!-- Post Content -->
                        <div class="post-content">
                            <span class="post-date"><span>26</span> March, 2019</span>
                             <h4>China destroys 30,000 world maps for showing Arunachal Pradesh as part of India</h4>
                            <p>Vodafone Idea (VIL) and Bharti Airtel's mobile service revenue in India likely grew sequentially for the first time in 11 quaters in the three months ended March.India and China have held 21 rounds of talks to resolve the border dispute.
                            </p>
                            <a href="https://www.indiatoday.in/world/story/china-india-arunachal-pradesh-destroy-maps-1486989-2019-03-26" class="read-more-btn" target="blank">Read More <i class="arrow_carrot-2right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Single Blog Post -->
                <div class="col-12 col-lg-4">
                    <div class="single-blog-post bg-img mb-80" style="background-image: url(./img/bg-img/in6.jpg);">
                        <!-- Post Content -->
                        <div class="post-content">
                            <span class="post-date"><span>13</span> March, 2019</span>
                            <h4>Indian naval crew has rescued more than 192 people in cyclone-hit Mozambique</h4>
                            <p>Cyclone Idai made landfall in East and Southern Africa around March 15, causing widespread destruction and loss of human lives in Mozambique, Zimbabwe and Malawi.As of now, the Indian naval crew has rescued more than 192.</p>
                            <a href="https://www.indiatoday.in/world/story/indian-naval-crew-has-rescued-more-than-192-people-in-cyclone-hit-mozambique-1485137-2019-03-24" class="read-more-btn" target="blank">Read More <i class="arrow_carrot-2right"></i></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- ***** Blog Area End ***** -->



    <!-- @extends('layout') -->
    @endsection('content')